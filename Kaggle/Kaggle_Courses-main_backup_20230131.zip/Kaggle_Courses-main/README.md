# Kaggle_Courses
https://www.kaggle.com/learn

PYTHON - 2022-01-17 https://www.kaggle.com/learn/python  
  
PANDAS - 2022-02-09 https://www.kaggle.com/learn/pandas

Intro to Machine Learning - 2022-02-20 https://www.kaggle.com/learn/intro-to-machine-learning

Intro to SQL - 2022-05-09 https://www.kaggle.com/learn/intro-to-sql

Advanced SQL - 2022-05-31 https://www.kaggle.com/learn/certification/wskimkaggle/advanced-sql

Intro to Programming - 2022-05-31 https://www.kaggle.com/learn/intro-to-programming

Intro to Deep Learning - 2022-06-14 https://www.kaggle.com/learn/intro-to-deep-learning
